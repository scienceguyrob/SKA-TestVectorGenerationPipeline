#!/bin/sh
python /state/partition1/lyon/ska_test_vectors/scripts/InjectPulsarAutomator.py  --cmd /home/lyon/DATA/CMDS/InjectPulsarCommandTest.txt --out /state/partition1/lyon/ska_test_vectors/pulsars