#ifndef CLK_TCK
#define CLK_TCK 100
#endif
