#ifndef _VANVLECK_H
#define _VANVLECK_H
void vanvleck9lev(float *rho,int npts);
int vanvleck3lev(float *rho,int npts);
//double inv_cerf(double input);
#endif
