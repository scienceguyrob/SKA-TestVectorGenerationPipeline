//-*-C++-*-
/***************************************************************************
 *
 *   Copyright (C) 2005 by Willem van Straten
 *   Licensed under the Academic Free License version 2.1
 *
 ***************************************************************************/

// psrchive/Base/Classes/Pulsar/Container.h

#ifndef __Pulsar_Container_h
#define __Pulsar_Container_h

#include "Reference.h"

namespace Pulsar {

  //! Data storage implementations
  class Container : public Reference::Able {

  };

}

#endif
