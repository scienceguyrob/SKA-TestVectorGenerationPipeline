/***************************************************************************
 *
 *   Copyright (C) 2006 by Willem van Straten
 *   Licensed under the Academic Free License version 2.1
 *
 ***************************************************************************/

#include "Pulsar/Pulsar.h"

bool Pulsar::range_checking_enabled = true;

Warning Pulsar::warning;
