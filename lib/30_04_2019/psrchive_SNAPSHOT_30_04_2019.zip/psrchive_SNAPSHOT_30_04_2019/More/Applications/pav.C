/***************************************************************************
 *
 *   Copyright (C) 2007 by David Smith
 *   Licensed under the Academic Free License version 2.1
 *
 ***************************************************************************/



#include "PavApp.h"




int main( int argc, char *argv[] )
{
  PavApp app;
  
  return app.run( argc, argv );
}






