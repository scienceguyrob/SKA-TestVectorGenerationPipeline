
# `fast_fake` (Build: 30/04/2019)
--
## Author: Rob Lyon
## Email : robert.lyon@manchester.ac.uk
## web   : www.scienceguyrob.com                                          

### Description

This version of `fast_fake` has been modified to prevent an incompatibility issue between `fast_fake` outputs, and `PRESTO`. The only difference between the code presented here, and the code in `Sigproc_MJK_SNAPSHOT_08_12_2016.zip`, is as follows.

In the file `fast_fake.c`, lines 144-147 have been commented out, to prevent the "signedness" parameter being written to the `fast_fake` output file headers. 

Original code on lines 144-147:

```
if (nbits==8){
  send_char("signed",OSIGN);
}
```

New code:

```
/* Commented out, as apparently this causes problems for PRESTO (see Rob Lyon).*/
/*if (nbits==8){
	send_char("signed",OSIGN);
}*/
```

No other functionality is affected, no other changes have been made.