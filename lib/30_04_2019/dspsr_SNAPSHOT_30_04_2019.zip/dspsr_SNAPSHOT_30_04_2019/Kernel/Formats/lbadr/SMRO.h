/***************************************************************************
 *
 *   Copyright (C) 2005 by Craig West
 *   Licensed under the Academic Free License version 2.1
 *
 ***************************************************************************/
// This file is to facilitate the changes from one packtype to another without needing to directly modify the source code

// Channel modes

#define CHAN2
//#define CHAN4
//#define CHAN8

// Bandwidth

#define MHZ16
//#define MHZ32
//#define MHZ4

// Packtype

#define SIGN_MAG
//#define OFFSET_BIN
