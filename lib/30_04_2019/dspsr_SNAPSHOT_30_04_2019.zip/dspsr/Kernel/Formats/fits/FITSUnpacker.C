/***************************************************************************
 *
 *   Copyright (C) 2008 by Jonathan Khoo & Willem van Straten
 *   Licensed under the Academic Free License version 2.1
 *
 ***************************************************************************/

#include "dsp/FITSUnpacker.h"
#include "dsp/FITSFile.h"
#include "Error.h"

#define ONEBIT_MASK 0x1
#define TWOBIT_MASK 0x3
#define FOURBIT_MASK 0xf

typedef float (dsp::FITSUnpacker::*BitNumberFn) (const int num);

using std::cerr;
using std::endl;
using std::vector;
using std::cout;

// Default zero offset for one-bit data.
const float ONEBIT_SCALE = 0.5;

// Default zero offset for four-bit data.
const float FOURBIT_SCALE = 7.5;

// Default zero offset for eight-bit data.
const float EIGHTBIT_SCALE = 31.5;

// Number of bits per byte.
const int BYTE_SIZE = 8;

dsp::FITSUnpacker::FITSUnpacker(const char* name) : Unpacker(name)
{
  zero_off = 0;
}

void dsp::FITSUnpacker::set_parameters (FITSFile* ff)
{
  /*
    WvS 2018 July 04 - Note that, if the CFITSIO library is not
    detected by the dspsr configure script, then the code that sets
    things up to call this method (in Signal/Pulsar/LoadToFold1.C)
    does not get compiled.  However, before today, not detecting
    CFITSIO (and therefore not defining HAVE_CFITSIO) did not stop one
    from enabling PSRFITS support (by including "fits" in
    backends.list).  Therefore, if everthing compiled and linked, it
    was possible for dspsr to run with PSRFITS support enabled but
    without CFITSIO-related code (like this method) enabled.
  */
  
#if _DEBUG
  cerr << "dsp::FITSUnpacker::set_parameters"
    " dat_scl size=" << ff->dat_scl.size() << endl;
#endif
  
  zero_off = ff->zero_off;
  dat_scl = ff->dat_scl;
  dat_offs = ff->dat_offs;
}

/**
 * @brief Iterate each row (subint) and sample extracting the values
 *        from input buffer and placing the scaled value in the appropriate
 *        position address by 'into'.
 * @throws InvalidState if nbit != 1, 2, 4 or 8.
 */

void dsp::FITSUnpacker::unpack()
{

  // Allocate mapping method to use depending on how many bits per value.
  BitNumberFn p;
  const unsigned nbit = input->get_nbit();

  if (verbose)
    cerr << "dsp::FITSUnpacker::unpack with nbit=" << nbit << endl;

  switch (nbit) {
    case 1:
      p = &dsp::FITSUnpacker::oneBitNumber;
      break;
    case 2:
      p = &dsp::FITSUnpacker::twoBitNumber;
      break;
    case 4:
      p = &dsp::FITSUnpacker::fourBitNumber;
      break;
    case 8:
      p = &dsp::FITSUnpacker::eightBitNumber;
      break;
    case 16:
      break;
    default:
      throw Error(InvalidState, "FITSUnpacker::unpack",
          "invalid nbit=%d", nbit);
  }

  const unsigned npol  = input->get_npol();
  const unsigned nchan = input->get_nchan();
  const unsigned ndat  = input->get_ndat();

  // Make sure scales and offsets exist
  if (dat_scl.size() == 0)
  {
#if _DEBUG
    cerr << "dsp::FITSUnpacker::unpack dat_scl empty" << endl;
#endif
    dat_scl.assign(nchan*npol,1);
    dat_offs.assign(nchan*npol,0);
  }

  // Number of samples in one byte.
  const int samples_per_byte = BYTE_SIZE / nbit;
  const int mod_offset = samples_per_byte - 1;

  const unsigned char* from = input->get_rawptr();
  const int16_t* from16 = (int16_t *)input->get_rawptr();

  if (nbit<=8) {

    // Iterate through input data, split the byte depending on number of
    // samples per byte, get corresponding mapped value and store it
    // as pol-chan-dat.
    //
    // TODO: Use a lookup table???
    for (unsigned idat = 0; idat < ndat; ++idat) {
      float* scl = &dat_scl[0];
      float* off = &dat_offs[0];
      for (unsigned ipol = 0; ipol < npol; ++ipol) {
        for (unsigned ichan = 0; ichan < nchan;) {

          const int mod = mod_offset - (ichan % samples_per_byte);
          const int shifted_number = *from >> (mod * nbit);

          float* into = output->get_datptr(ichan, ipol) + idat;

#if 0
          cerr << "ipol=" << ipol << " ichan=" << ichan 
               << " scl=" << *scl << " off=" << *off << endl;
#endif
   
          *into = (*this.*p)(shifted_number) * (*scl) + (*off);
          ++scl; ++off;

          // Move to next byte when the entire byte has been split.
          if ((++ichan) % (samples_per_byte) == 0) {
            ++from;
          }
        }
      }
    }
  }

  else if (nbit==16) {
    for (unsigned idat=0; idat<ndat; idat++) {
      float* scl = &dat_scl[0];
      float* off = &dat_offs[0];
      for (unsigned ipol=0; ipol<npol; ipol++) {
        for (unsigned ichan=0; ichan<nchan; ichan++) {
          float* into = output->get_datptr(ichan, ipol) + idat;
          *into = (float)(*from16) * (*scl) + (*off);
          ++scl; ++off;
          ++from16;
        }
      }
    }
  }

}

bool dsp::FITSUnpacker::matches(const Observation* observation)
{
  return observation->get_machine() == "FITS";
}


/**
 * @brief Mask and scale ( - 0.5) a one-bit number.
 * @param int Contains an unsigned one-bit number to be masked and scaled
 * @return Scaled one-bit value.
 */

float dsp::FITSUnpacker::oneBitNumber(const int num)
{
  const int masked_number = num & ONEBIT_MASK;
  //return masked_number - ONEBIT_SCALE;
  return masked_number - zero_off;
}


/**
 * @brief Scale the eight-bit number ( - 31.5).
 * @param int Eight-bit number to be scaled
 * @return Scaled eight-bit value.
 */

float dsp::FITSUnpacker::eightBitNumber(const int num)
{
  //return num - EIGHTBIT_SCALE;
  return num - zero_off;
}


/**
 * @brief Mask (0xf) and scale ( - 7.5) an unsigned four-bit number.
 * @param int Contains the unsigned four-bit number to be scaled.
 * @returns float Scaled four-bit value.
 */

float dsp::FITSUnpacker::fourBitNumber(const int num)
{
  const int masked_number = num & FOURBIT_MASK;
  //return masked_number - FOURBIT_SCALE;
  return masked_number - zero_off;
}


/**
 * @brief Mask (0x3) and scale an unsigned two-bit number:
 *        0 = -2
 *        1 = -0.5
 *        2 = 0.5
 *        3 = 2.0
 *
 * @param int Contains the unsigned two-bit number to be scaled.
 * @returns float Scaled two-bit value.
 */

float dsp::FITSUnpacker::twoBitNumber(const int num)
{
  const int masked_number = num & TWOBIT_MASK;
  switch (masked_number) {
    case 0:
      return -2.0;
    case 1:
      return -0.5;
    case 2:
      return 0.5;
    case 3:
      return 2.0;
    default:
      return 0.0;
  }
}
